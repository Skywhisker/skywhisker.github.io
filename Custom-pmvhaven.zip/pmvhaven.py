"""
    Cumination
    Copyright (C) 2024 Team Cumination, lairdweller

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import json
import xbmc
from six.moves import urllib_parse
from resources.lib import utils
from resources.lib.adultsite import AdultSite


site = AdultSite("pmvhaven", "[COLOR hotpink]PMV Haven[/COLOR]", 'https://pmvhaven.com', "pmvhaven.png", "pmvhaven")
ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'
tags = ['PMV', 'Compilation', 'Blowjob', 'Big Ass', 'Big Boobs', 'Cumshot', 'Teen', 'Riding', 'Big Dick', 'Cute', 'Hardcore', 'Doggystyle', 'Splitscreen', 'Facial', 'Cum', 'Bouncing Tits', 'Cum On Face', 'Goon', 'Cowgirl', 'Brunette', 'BBC', 'Blonde', 'Anal', 'Teasing', 'Ass', 'Shake', 'Dancing', 'Oral', 'interracial', 'big tits', 'TikTok', 'Deepthroat', 'Multiple Girls', 'PAWG', 'Twerking', 'Gooning', 'Cum In Mouth', 'Asian', 'POV', 'Missionary', 'Rough']
sorts = ['Newest','Top Rated','Most Viewed']
times = ['All time', 'Today','Last 7 days','Last 30 days']

categories = ['hmv','hypno','koreanbj','pmv','tiktok']
pmvhaven_headers = {
                  'Accept': 'application/json',
                  'Content-Type': 'text/plain;charset=UTF-8',
                  }
getinput = utils._get_keyboard


@site.register(default_mode=True)
def pmvhaven_main():
    site.add_dir('[COLOR hotpink]Categories and Tags[/COLOR]', site.url, 'filter', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url, 'pmvhaven_search', site.img_search)
    pmvhaven_discover()



@site.register()
def pmvhaven_discover():
    siteurl = "https://pmvhaven.com/api/v2/videoInput" 
    headers = {'Accept':'application/json', 'Content-Type': 'application/json'}
    data = {"mode":"GetDiscover"}
    
    try:
        listhtml = utils.postHtml(siteurl, json_data=data, headers=headers)
    except Exception as e:
        utils.notify('Notify', str(e))
        return None
    hits = json.loads(listhtml)
    videos = hits['data']
    for video in videos:
        name = video['title']
        videoid = video['url']
        img = video['thumbnails'][-1]
        plot = ''
        site.add_download_link(name, videoid, 'pmvhaven_play_combined', img, plot)
    utils.eod()

@site.register()
def pmvhaven_list(page):
    data=json.loads(page)
    siteurl = 'https://pmvhaven.com/api/getmorevideos'
    _user_agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 ' + \
                  '(KHTML, like Gecko) Chrome/13.0.782.99 Safari/535.1'
    try:
        listhtml = utils.postHtml(siteurl, json_data=data, headers=pmvhaven_headers)
    except Exception as e:
        utils.notify('Notify', str(e))
        return None
    hits = json.loads(listhtml)
    videos = hits['data']
    for video in videos:
        name = video['title']
        videoid = video['url']
        img = video['thumbnails'][-1]
        plot = ''
        site.add_download_link(name, videoid, 'pmvhaven_play_combined', img, plot)
    next_data=data.copy()
    next_data['index']+=1
    site.add_dir('Next Page', site.url, 'pmvhaven_list', site.img_next, page=json.dumps(next_data))
    utils.eod()


@site.register()
def pmvhaven_search(keyword=None, page=1):
    if not keyword:
        site.search_dir(site.url, 'pmvhaven_search')
    else:
        search(keyword=keyword, page=1)

@site.register()
def search(keyword, page=1):
    siteurl = 'https://pmvhaven.com/api/v2/search'
    data = {
            "data": keyword,
            "mode":"DefaultMoreSearch",
            "index":page,
            }
    _user_agent = 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/535.1 ' + \
                  '(KHTML, like Gecko) Chrome/13.0.782.99 Safari/535.1'
    try:
        listhtml = utils.postHtml(siteurl, json_data=data, headers={'User-Agent': _user_agent})
    except Exception as e:
        utils.notify('Notify', str(e))
        return None
    hits = json.loads(listhtml)
    videos = hits['data']
    for video in videos:
        name = video['title']
        videoid = video['url']
        img = video['thumbnails'][-1]
        plot = ''
        site.add_download_link(name, videoid, 'pmvhaven_play_combined', img, plot)
    site.add_dir('Next Page', site.url, 'search', site.img_next, page=page+1, keyword=keyword)
    utils.eod()


@site.register()
def filter():
    selected_categories = [categories[i] for i in utils.dialog.multiselect('Select (one, multiple, or no) categories to filter on', categories)]
    selected_tags = [tags[i] for i in utils.dialog.multiselect('Select (one, multiple, or no) tags to filter on', tags)]
    selected_sort = sorts[utils.dialog.select('Sort by', sorts)]
    selected_time = times[utils.dialog.select('For time:', times)]
    data = {"activeTime":selected_time,
            "activeView":selected_sort,
            "tags": selected_tags,
            "music": [],
            "stars": [],
            "creators": [],
            "range":[0,40],
            "index":1,
            }
    if selected_categories==[]:
        selected_categories=['all']
    for category in selected_categories:
        if category not in data:
            data[category] = True
    pmvhaven_list(page=json.dumps(data))

@site.register()
def pmvhaven_play(url, name, download=None):
    pmvhaven_play_combined(url, name, download)

@site.register()
def pmvhaven_play_combined(url, name):
    scheme, netloc, path, qs, anchor = urllib_parse.urlsplit(url)
    utils.VideoPlayer(name).play_from_direct_link(urllib_parse.urlunsplit((scheme, netloc, urllib_parse.quote(path), urllib_parse.quote(qs), urllib_parse.quote(anchor))))
